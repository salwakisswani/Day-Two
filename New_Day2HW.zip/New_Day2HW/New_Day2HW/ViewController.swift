//
//  ViewController.swift
//  DayTwo HW
//
//  Created by Admin on 6/19/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let PLUS = 10
    let MINUS = 11
    let MULTIPLY = 12
    let DIVIDE = 13
    
    @IBOutlet var lblText : UILabel!
    
    var num1 : NSInteger = 0
    var num2 : NSInteger = 0
    var operand : NSInteger = 0
    var answer : Double = 0.0
    
    var theNumber : String = "0"
    
    //for equal sign answers
    
    @IBAction func calculate(sender : UIButton){
        num2 = Int(theNumber)!
            
        if operand == PLUS {
            answer = Double(num1 + num2)
            }
        if operand == MINUS {
            answer = Double(num1 - num2)
        }
        
        if operand == MULTIPLY {
            answer = Double(num1 - num2)
        }
        
        if operand == DIVIDE {
            // so the app doesn't crash for older models because you can't divide by zero
            if num2 == 0 {
                //create an alert box
                let alert = UIAlertController(title:"Error", message: "Sorry love you can't divide by zero ", preferredStyle: .alert)
                //option to cancel the alert
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel
                    , handler: nil)
                
                alert.addAction(cancelAction)
            
                //IOS styled
                present(alert, animated: true)
                
                //divide is complete with error message if divided by zero
                
            }
            else {
            answer = Double(num1) / Double(num2)
        }
        }
            
            func viewDidLoad() {
                super.viewDidLoad()
                // Do any additional setup after loading the view.
                
                printNumber()
                
                
            }
            
        
        //Clearing up
        num1 = 0
        num2 = 0
        operand = PLUS
        theNumber = String(answer)
            
        
        answer = 0.0
        theNumber = "0"
        
    }
    
    
    //an event handler for operations
        func setOperand(sender : UIButton){
        if sender.tag >= 10 && sender.tag <= 13 {
            operand = sender.tag
            saveNum1()
        }
        
        //for the clear button
        if sender.tag == -2 {
            theNumber = "0"
            printNumber()
        }
    }
    
    //to save the number on the screen
    
    func saveNum1() {
        num1 = Int(theNumber)!
        theNumber = "0"
        printNumber()
    }
    
     
    
    func printNumber(){
        lblText.text = theNumber
        
    }
    
    // adding an event handler to support the buttons
    // make sure the numbers are only from 0 to 9
    // if correct, append and update lable with print 
    
        func pressNum(sender: UIButton){
        if sender.tag >= 0 && sender.tag <= 9 {
            theNumber += String(sender.tag)
            printNumber()

}
}
}
